// login.js
// let host = '45.79.205.197';
// let port = '8001';
// let settings;
// let auth;
// let api = 'http://' + host + ':' + port + '/rms/api/';
// const { ipcRenderer, remote } = require('electron');
// const { dialog } = remote;

// // HTML content as a string
// document.getElementById('loginBtn').addEventListener('click', async function() {
//     const userId = document.getElementById('userId').value;

//     if (!userId) {
//         alert('Please enter a User ID.');
//         return;
//     }

//     // Send a POST request to the server to login with the entered user ID
//     fetch('http://45.79.205.197:8001/login', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({ userId: userId })
//     })
//     .then(response => {
//         if (response.ok) {
//             // Handle successful login response
//             return response.json().then(data => {
//                 // Check if settings are found
//                 if (data.success && data.settings) {
//                     // Redirect to the protected page or perform any other action upon successful login
//                     $("#settingsModal").on("hide.bs.modal", function () {

//                         setTimeout(function () {
//                             if (settings !== undefined && auth != undefined) {
//                                 $('#settingsModal').modal('show');
//                             }
//                         }, 1000);
            
//                     });
//                 } else {
//                     // Handle case when settings are not found
//                     alert('Settings not found for this user.');
//                 }
//             });
//         } else {
//             // Handle error response
//             return response.json().then(data => {
//                 alert(data.error);
//             });
//         }
//     })
//     .catch(error => {
//         console.error('Error:', error);
//         alert('An error occurred. Please try again.');
//     });
// });
