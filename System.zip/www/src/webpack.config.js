// webpack.config.js
const webpack = require('webpack');
const path = require('path');

module.exports = {
    entry: {
        index: './index.js',
        pos: '../www/js/pos.js'
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: '[name].bundle.js'
    },
    resolve: {
        fallback: {
            'worker_threads': require.resolve('worker_threads'),
            'stream': require.resolve('stream-browserify'),
             "fs": false, // or require.resolve("browserfs/dist/shims/fs.js")
             "process": false,
            "child_process": false // or require.resolve("child_process-browserify")
        },
        alias: {
            'global': path.resolve(__dirname, './global.js') // Create global.js file with 'window' exported
        }
    },
    externals: {
        'worker_threads': 'worker_threads',
        'write-file-atomic': 'write-file-atomic',
        'conf': 'conf'
    },
    target: 'web',
    plugins: [
        new webpack.ProvidePlugin({
            window: 'this'
        }),
        
    ]
};

