
let path = require('path');
let moment = require('moment');
//let Swal = require('sweetalert2');
let { ipcRenderer } = require('electron');
let Store = require('electron-store');
const remote = require('electron').remote;
let btoa = require('btoa');
const { jsPDF } = require('jspdf');
let html2canvas = require('html2canvas');
let JsBarcode = require('jsbarcode');
let macaddress = require('macaddress');
